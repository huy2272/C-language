// int Srch(char *fname, char *str);
void CurrFile(char *fname);
void Report(int hits, char *fname, const char *str);
int Traverse(const char *argv);
int SrchAndReplace(char *fname, const char *argv);
int Count(char *fname, const char *str);